# fckw3

## What it does

This extension just includes:

* a content script, "fckw3.js", that is injected into any pages
under "google/", "duckduckgo/", or any of their subdomains

The content script removes w3schools from search result
